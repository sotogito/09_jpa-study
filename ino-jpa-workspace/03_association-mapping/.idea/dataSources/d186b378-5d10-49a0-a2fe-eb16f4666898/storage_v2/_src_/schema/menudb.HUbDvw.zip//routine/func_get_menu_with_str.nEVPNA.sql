create
    definer = ino@`%` function func_get_menu_with_str(param_menu varchar(50)) returns varchar(100)
BEGIN
    DECLARE result VARCHAR(100);
    SET result = CONCAT('*', param_menu, 'helloWorld');
    RETURN result;
END;

