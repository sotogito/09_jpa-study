create
    definer = ino@`%` procedure proc_loop(IN n int, OUT result int)
BEGIN  
    DECLARE i INT DEFAULT 1; -- 증감변수
    SET result = 0;
    sum_label: LOOP
        SET result = result + i;
        SET i = i + 1;
        IF i > n THEN LEAVE sum_label;
        END IF;
    END LOOP;
END;

