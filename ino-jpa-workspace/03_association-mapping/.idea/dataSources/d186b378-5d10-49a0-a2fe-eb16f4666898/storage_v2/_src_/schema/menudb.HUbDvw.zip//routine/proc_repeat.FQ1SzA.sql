create
    definer = ino@`%` procedure proc_repeat(OUT result int)
BEGIN
    DECLARE i INT DEFAULT 0;
    SET result = 1;
    REPEAT
        SET i = i + 1;
        SET result = i;
    UNTIL i * i > 1000 END REPEAT;
    SET result = POW(result -1,2);
END;

